console.log("Menú cargado con amor 💕");

// Aquí podrías hacer animaciones o interacciones si lo necesitas.


